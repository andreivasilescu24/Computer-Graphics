#pragma once

class Life
{
public:
    float x, y;

    Life(float x, float y)
        : x(x),
          y(y)
    {
    }
};
