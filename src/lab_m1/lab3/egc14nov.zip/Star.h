#pragma once

class Star
{
public:
    int X, Y;

    Star(int x, int y)
        : X(x),
          Y(y)
    {
    }
};
